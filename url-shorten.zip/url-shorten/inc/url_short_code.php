<?php
ob_start();
function url_shorten_details(){
    //define wpdb globally
    global $wpdb;
    //get the long url and convert into a short url
    if(isset($_POST['short_url'])){    
    $url=$_POST["url_value"];
    $address = $_REQUEST['ip_address'];
    //in here i have used Mersenne Twister algorithm for generating random number
    $short_url=substr(md5($url.mt_rand()),0,8);
    $table_name = $wpdb->prefix."short_urls";
    //inserting into wpdb
    $insert_data = "INSERT INTO ".$table_name."(long_url, short_url, ip_address) values ('$url','$short_url','$address')";
    $result = $wpdb->query($insert_data);
    if($result){
    $output_short_url = "Your New URL Is : http://xyz.com/url.php?u=".$short_url."";
    } else {
    echo "There are some error, Please check.";
    } 
    }
    
    //convert short url to long url
    if(isset($_POST['original_url']))
    {
    $url=$_POST["short_url_value"];
    $short_url=substr($url,25);
    $table_name = $wpdb->prefix."short_urls";
    //query from wpdb
    $query_short_url = "SELECT * FROM ".$table_name." where short_url='".$short_url."'";
    //getting the value as object
    $getresult = $wpdb->get_results($query_short_url, OBJECT);
    //store it to a variable
    $output_long_url = $getresult[0]->long_url;
    }
?>
    <div class="donation-form-sec">            
        <h2>Long URL to Short URL</h2>
        <form method="post" action="">
        <input type="text" name="url_value" placeholder="Enter URL" required><br/>
        <input type="submit" name="short_url" value="Submit">
        <input type="hidden" name="ip_address" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
        </form>
        <?php echo $output_short_url;?>

        <h2>Short URL to Long URL</h2>
        <form method="post" action="">
        <input type="text" name="short_url_value" placeholder="Enter Short URL" required><br/>
        <input type="submit" name="original_url" value="Submit">
        </form>
        <?php echo $output_long_url;?>
    </div>
<?php } 
add_shortcode('url_shorten', 'url_shorten_details');
return ob_get_clean();