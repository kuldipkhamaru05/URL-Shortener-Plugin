<?php
/*
  * Plugin Name: URL Shorten
  * Description: This plugin allow user to short and long the links as well.
  * Version: 1.0
  * Author: Kuldip Khamaru
*/

    if (!defined('ABSPATH')){
        //Exit if accessed directly
        exit;
    }
    include_once('inc/url_short_code.php');
    global $cltd_example_db_version;
    $cltd_example_db_version = '1.1'; // version changed from 1.0 to 1.1

    function cltd_example_install()
    {
        global $wpdb;
        global $cltd_example_db_version;
        $table_name = $wpdb->prefix . 'short_urls'; // do not forget about tables prefix
        /*
        *when the plugin will activate then the table will automaitically created along with below fields
        *(i.e: id, long_url, short_url, ip_address, entrydate)
        */
        $sql = "CREATE TABLE " . $table_name . " (
          id int(11) NOT NULL AUTO_INCREMENT,
          long_url TEXT NOT NULL,
          short_url TEXT NOT NULL,
          ip_address VARCHAR(255) NOT NULL,
          entrydate timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,      
          PRIMARY KEY  (id)
        );";
        /*
         * we do not execute sql directly
         *we are calling dbDelta which cant migrate database
         */
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        // save current database version for later use (on upgrade)
        add_option('cltd_example_db_version', $cltd_example_db_version);
    }
    register_activation_hook(__FILE__, 'cltd_example_install');

    /**
     * Trick to update plugin database, see docs
     */
    function cltd_example_update_db_check()
    {
        global $cltd_example_db_version;
        if (get_site_option('cltd_example_db_version') != $cltd_example_db_version) {
            cltd_example_install();
        }
    }
    add_action('plugins_loaded', 'cltd_example_update_db_check');

    //add settings page to the admin panel
    add_action( 'admin_menu', 'vote_admin_menu' ); 
    function vote_admin_menu() {
        add_options_page(
            'URLS',
            'URL Plugin Settings',
            'manage_options',
            'url-plugin',
            'url_options_page'
        );
    }
    
    function url_options_page() {
        ?>
        <div class="wrap">
            <h2>URL Plugin Usage Details</h2>
            <p>Please copy the shortcode <b>( [url_shorten] )</b> and paste in the page editor.</p>
            <ul>
                <li>After pasting the shortcode you can see that there are 2 forms on the front end.</li>
                <li>One is for Long URL to Short URL.</li>
                <li>Another one is for Short URL to Long URL.</li>
                <li>If you test the things from front end then go to the back end.</li>
                <li>You will found an area named <b>URLS</b>.</li>
                <li>From there you can be able to check the URL Details that you just did.</li>
            </ul>
        </div>
        <?php
    }

    /**
     * PART 2. Defining Custom Table List
     */
    if (!class_exists('WP_List_Table')) {
        require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
    }

    class Custom_Table_Example_List_Table extends WP_List_Table
    {
        function __construct()
        {
            global $status, $page;
    
            parent::__construct(array(
                'singular' => 'url',
                'plural' => 'urls',
            ));
        }
    
        function column_default($item, $column_name)
        {
            return $item[$column_name];
        }
    
        function column_age($item)
        {
            return '<em>' . $item['ip_address'] . '</em>';
        }
    
        function column_name($item)
        {
            $actions = array(
                'edit' => sprintf('<a href="?page=urls_form&id=%s">%s</a>', $item['id'], __('View', 'ff')),
                'delete' => sprintf('<a href="?page=%s&action=delete&id=%s">%s</a>', $_REQUEST['page'], $item['id'], __('Delete', 'ff')),
            );
    
            return sprintf('%s %s',
                $item['long_url'],
                $this->row_actions($actions)
            );
        }

        function column_cb($item)
        {
            return sprintf(
                '<input type="checkbox" name="id[]" value="%s" />',
                $item['id']
            );
        }
        
        //back end column names
        function get_columns()
        {
            $columns = array(
                'cb' => '<input type="checkbox" />', //Render a checkbox instead of text
                'long_url' => __('Long URL', 'cltd_example'),
                'short_url' => __('Short URL', 'cltd_example'),
                'ip_address' => __('IP Address', 'cltd_example'),
                'entrydate' =>__('Date', 'cltd_example'),
            );
            return $columns;
        }
        
        //sort column values
        function get_sortable_columns()
        {
            $sortable_columns = array(
                'long_url' => array('long_url', false),
                'short_url' => array('short_url', false),
                'ip_address' => array('ip_address', false),             
                'entrydate' =>array('entrydate', false),
            );
            return $sortable_columns;
        }
        
        //bulk delete operation from back end
        function get_bulk_actions()
        {
            $actions = array(
                'delete' => 'Delete'
            );
            return $actions;
        }
    
        /**
         * This method processes bulk actions
         */
        function process_bulk_action()
        {
            global $wpdb;
            $table_name = $wpdb->prefix . 'short_urls'; // do not forget about tables prefix
    
            if ('delete' === $this->current_action()) {
                $ids = isset($_REQUEST['id']) ? $_REQUEST['id'] : array();
                if (is_array($ids)) $ids = implode(',', $ids);
    
                if (!empty($ids)) {
                    $wpdb->query("DELETE FROM $table_name WHERE id IN($ids)");
                }
            }
        }
    
        /**
         * [REQUIRED] This is the most important method
         * It will get rows from database and prepare them to be showed in table
         */

         function prepare_items()
            {
                global $wpdb;
                $table_name = $wpdb->prefix . 'short_urls'; // do not forget about tables prefix
                $per_page = 20; // constant, how much records will be shown per page
                $columns = $this->get_columns();
                $hidden = array();
                $sortable = $this->get_sortable_columns();
                // here we configure table headers, defined in our methods
                $this->_column_headers = array($columns, $hidden, $sortable);
                // [OPTIONAL] process bulk action if any
                $this->process_bulk_action();
                // will be used in pagination settings
                $total_items = $wpdb->get_var("SELECT COUNT(id) FROM $table_name");
                // prepare query params, as usual current page, order by and order direction
                $paged = isset($_REQUEST['paged']) ? max(0, intval($_REQUEST['paged']) - 1) : 0;
                $orderby = (isset($_REQUEST['orderby']) && in_array($_REQUEST['orderby'], array_keys($this->get_sortable_columns()))) ? $_REQUEST['orderby'] : 'id';
                $order = (isset($_REQUEST['order']) && in_array($_REQUEST['order'], array('asc', 'desc'))) ? $_REQUEST['order'] : 'asc';
                $this->items = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name ORDER BY $orderby $order LIMIT %d OFFSET %d", $per_page, $paged), ARRAY_A);
                // [REQUIRED] configure pagination
                $this->set_pagination_args(array(
                    'total_items' => $total_items, // total items defined above
                    'per_page' => $per_page, // per page constant defined at top of method
                    'total_pages' => ceil($total_items / $per_page) // calculate pages count
                ));
            }   
    }

    /**
     * PART 3. Admin page
     */
    function cltd_example_admin_menu()
    {
        add_menu_page(__('URLS', 'cltd_example'), __('URLS', 'cltd_example'), 'activate_plugins', 'URLS', 'cltd_example_Donners_page_handler');
        add_submenu_page('URLS', __('URLS', 'cltd_example'), __('URLS', 'cltd_example'), 'activate_plugins', 'URLS', 'cltd_example_Donners_page_handler');
        // add new will be described in next part
        add_submenu_page( null, __('Add new', 'cltd_example'), __('Add new', 'cltd_example'), 'activate_plugins', 'urls_form', 'cltd_example_Donners_form_page_handler');
    }
    add_action('admin_menu', 'cltd_example_admin_menu');

    /**
     * List page handler
     */
    function cltd_example_Donners_page_handler()
    {
        global $wpdb;
        $table = new Custom_Table_Example_List_Table();
        $table->prepare_items();
        //$table->search_box('search', 'search_id');
        $message = '';
        if ('delete' === $table->current_action()) {
            $message = '<div class="updated below-h2" id="message"><p>' . sprintf(__('Items deleted: %d', 'cltd_example'), count($_REQUEST['id'])) . '</p></div>';
        }
        ?>
        <div class="wrap">
            <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
            <h2><?php _e('URL Details', 'cltd_example')?></h2>
            <?php echo $message; ?>
            <form id="url-table" method="GET">
                <?php $table->display() ?>
            </form>
            <?php
                if( isset($_POST['s']) ){
                $table->prepare_items($_POST['s']);
                } else {
                $table->prepare_items();
                }
            ?>
        </div>
    <?php } ?>
    <div class="wrap">
        <div class="icon32 icon32-posts-post" id="icon-edit"><br></div>
        <h2><?php _e('URLS', 'cltd_example')?> 
            <?php 
            $path = 'admin.php?page=URLS';
            $url = admin_url($path);
             ?>
            <a class="add-new-h2" href="<?php echo $url;?>"><?php _e('back to list', 'cltd_example')?></a>
        </h2>
        <div id="col-container">
                <div class="col-wrap">
                <h3>URL Details</h3>
                <table class="widefat">                
                    <tbody>
                        <tr><th>Long URL</th><td><?php echo $item['long_url'];?></td></tr>
                        <tr><th>Short URL</th><td><?php echo $item['short_url'];?></td></tr>
                        <tr><th>IP Address</th><td><?php echo $item['ip_address'];?></td></tr>
                        <tr><th>Date</th><td><?php echo $item['entrydate'];?></td></tr>
                    </tbody>
                </table>
                </div> 
        </div>    
    </div>    
    <?php
    return ob_get_clean();
    function cltd_example_languages()
    {
    load_plugin_textdomain('cltd_example', false, dirname(plugin_basename(__FILE__)));
    }
    add_action('init', 'cltd_example_languages');