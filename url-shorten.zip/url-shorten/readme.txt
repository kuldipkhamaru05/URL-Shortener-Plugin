=== Plugin Name : URL Shortener ===
Author: Kuldip Khamaru
Requires at least: 3.0.1
Tested up to: 4.9.7
Requires PHP: 5.2.4
Stable tag: 4.3

== Installation ==

1. Upload the plugin to the /wp-content/plugins/ directory or you can do that from back end as well.
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Place [url_shorten] shortcode in your page editor or call ir via template file using do_shortcode function.
4. You will found the instructions under Settings -> URL Plugin Settings.

== Description of the plugin ==

This plugin allow users to convert their Short URL to Long URL and Long URL to Short URL. Also, you can check the details from below as well.

Please copy the shortcode [url_shorten]  and paste in the page editor.
After pasting the shortcode you can see that there are 2 forms on the front end.
One is for Long URL to Short URL.
Another one is for Short URL to Long URL.
If you test the things from front end then go to the back end.
You will found an area named URLs.
From there you can be able to check the URL Details that you just did.

